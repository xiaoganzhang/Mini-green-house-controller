package com.example.logintest14.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.logintest14.R;
import com.example.logintest14.databinding.FragmentHomeBinding;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.BreakIterator;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    private Button btn_update;
    private TextView textView;

    private TextView textView_h;//humidity

    private TextView textView_CO2;//co2

    private Button button2;
    Socket soc = null;
    private void acceptServer() throws IOException {

        Socket socket = null;
        try {
            socket = new Socket("172.16.2.54", 12345);
        } catch (IOException e) {
            e.printStackTrace();
        }

        OutputStream os = null;
        try {
            os = socket.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        PrintWriter pw = new PrintWriter(os);

        InetAddress address = null;
        try {
            address = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        String ip = address.getHostAddress();
        pw.write("server：~" + ip + "~ connect！！");
        pw.flush();
        try {
            socket.shutdownOutput();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, null);

        btn_update= (Button)view.findViewById(R.id.button);
        textView = (TextView)view.findViewById(R.id.textView10);

        textView_h = (TextView)view.findViewById(R.id.textView9);

        textView_CO2 = (TextView)view.findViewById(R.id.textView8);

        btn_update.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                BreakIterator editsend = null;
                String msg = editsend.getText().toString();
                String number = msg;
                String humidity = msg;
                String co2 = msg;

                textView.setText(String.valueOf(number));
                textView_h.setText(String.valueOf(humidity));
                textView_CO2.setText(String.valueOf(co2));



            }
        });
        return view;
    }
    /*
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

///////////////////////////////////////////////////////////////////////////////////////
        View view = inflater.inflate(R.layout.fragment_home, null);

          textView = (TextView)view.findViewById(R.id.textView10);
          btn_update = (Button)view.findViewById(R.id.button);
          btn_update.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                Toast.makeText(getActivity(), "Clicked", Toast.LENGTH_LONG).show();
                float number = (float)(Math.random());

                textView.setText(String.valueOf(number));
            }
           });
//////////////////////////////////////////////////////////////////////////////////////////////

        return root;
    }


*/















    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;




//        et_tem = et_tem.findViewById(R.id.textView10);

//        button_update = button_update.findViewById(R.id.button);
//        button_update.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                float number = (float)(Math.random());
//
//                et_tem.setText(String.valueOf(number));
//
//
//
//            }
//        });





    }

}