package com.example.logintest14.ui.dashboard;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.logintest14.R;
import com.example.logintest14.databinding.FragmentDashboardBinding;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.BreakIterator;

public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;

    private TextView mushroom_des ;
    private Button btn_desp;

    private Button btn_pic;
    private ImageView image;
    public void createServerRecevied() {

        ServerSocket serverSocket = null;

        try {

            serverSocket = new ServerSocket(8081);

            Socket socket = serverSocket.accept();

            DataInputStream inputStream = new DataInputStream(socket.getInputStream());

            long len = inputStream.readLong();
            System.out.println("len = " + len);
            byte[] bytes = new byte[(int) len];

            inputStream.readFully(bytes);

            File file = new File("app/res/drawable/mushroom2" + len + ".jpg");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(bytes);
  
            Log.i("ServerReceviedByTcp","fileOutputStream.read ok" );
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, null);

        btn_desp= (Button)view.findViewById(R.id.button5);
        mushroom_des = (TextView)view.findViewById(R.id.MushroomDES);
        btn_pic = (Button) view.findViewById(R.id.button4);
        image = (ImageView)view.findViewById(R.id.imageView) ;

        btn_desp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                BreakIterator editsend = null;
                assert false;
                String msg = editsend.getText().toString();


                mushroom_des.setText(msg);



            }
        });

        btn_pic.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                image.setImageDrawable(getResources().getDrawable(R.drawable.mushroom2));


            }
        });








        return view;
    }
//
//    public View onCreateView(@NonNull LayoutInflater inflater,
//                             ViewGroup container, Bundle savedInstanceState) {
//        DashboardViewModel dashboardViewModel =
//                new ViewModelProvider(this).get(DashboardViewModel.class);
//
//        binding = FragmentDashboardBinding.inflate(inflater, container, false);
//        View root = binding.getRoot();
//
//        final TextView textView = binding.textDashboard;
//        dashboardViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
//        return root;
//    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;






    }
}