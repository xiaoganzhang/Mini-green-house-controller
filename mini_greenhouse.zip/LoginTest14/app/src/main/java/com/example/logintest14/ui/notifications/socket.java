package com.example.logintest14.ui.notifications;



import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import androidx.appcompat.app.AppCompatActivity;


class MainActivity extends AppCompatActivity {
    @SuppressLint("NonConstantResourceId")

    EditText etIp;
    //    @SuppressLint("NonConstantResourceId")
//    @BindView(R.id.btn_connect)
//    Button Btn_serviceConnect;
//    @SuppressLint("NonConstantResourceId")
//    @BindView(R.id.tv_receive)
//    TextView tvReceive;
    @SuppressLint("NonConstantResourceId")

    TextView tvContent;
    @SuppressLint("NonConstantResourceId")

    EditText etInput;
    //    @SuppressLint("NonConstantResourceId")
//    @BindView(R.id.btn_send)
//    Button btnSend;
    @SuppressLint("NonConstantResourceId")

    ScrollView svContent;
//    @SuppressLint("NonConstantResourceId")
//    @BindView(R.id.btn_service)
//    Button btnservice;

    private StringBuffer strMsg = new StringBuffer();

    private final int MESSAGE_ERROR = 0;
    private final int MESSAGE_SUCCEED = 1;
    private final int MESSAGE_RECEIVE = 2;

    private Socket sock;
    private OutputStream outx;
    private InputStream inx;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        //启动服务端
        new Thread(() -> new Server().startService()).start();
    }

//    @SuppressLint("NonConstantResourceId")
//
//    public void onViewClicked(View view) {
//        switch (view.getId()) {
//            case R.id.btn_connect://连接服务端
//                String strip = etIp.getText().toString().trim();
//                if (strip.contains(":")) {
//                    //启动连接
//                    new Socket_thread(strip).start();
//                }
//                break;
//            case R.id.btn_service:
//                if (!TextUtils.isEmpty(etInput.getText().toString())) {
//                    sendString("服务端：" + etInput.getText().toString().trim());
//                    etInput.setText("");
//                } else {
//                    Toast.makeText(this, "输入不可为空", Toast.LENGTH_SHORT).show();
//                }
//                break;
//            case R.id.btn_send:
//                if (!TextUtils.isEmpty(etInput.getText().toString())) {
//                    sendStrSocket("客户端：" + etInput.getText().toString().trim());
//                    etInput.setText("");
//                } else {
//                    Toast.makeText(this, "输入不可为空", Toast.LENGTH_SHORT).show();
//                }
//                break;
//        }
//    }

    /**
     * 连接服务器
     */
    class Socket_thread extends Thread {
        private String IP = "127.0.0.1";//ip地址
        private int PORT = 8081;//port

        public Socket_thread(String strip) {
            //如: 127.0.0.1:8081
            String[] stripx = strip.split(":");
            this.IP = stripx[0];
            this.PORT = Integer.parseInt(stripx[1]);
        }

        @Override
        public void run() {
            try {
                disSocket();
                //连接服务器，此处会一直处于阻塞，直到连接成功
                sock = new Socket(this.IP, this.PORT);
                //阻塞停止，表示连接成功
                setMessage("successful", MESSAGE_SUCCEED);
            } catch (Exception e) {
                setMessage("error", MESSAGE_ERROR);
                e.printStackTrace();
                return;
            }
            try {
                //获取到输入输出流
                outx = sock.getOutputStream();
                inx = sock.getInputStream();
            } catch (Exception e) {
                setMessage("error", MESSAGE_ERROR);
                e.printStackTrace();
                return;
            }
            new Inx().start();
        }
    }

    /**
     * 循环接收数据
     */
    class Inx extends Thread {
        @Override
        public void run() {
            while (true) {
                byte[] bu = new byte[1024];
                try {
                    int conut = inx.read(bu);//设备重启，异常 将会一直停留在这
                    if (conut == -1) {
                        setMessage("disconnet", MESSAGE_ERROR);
                        disSocket();
                        return;
                    }

                    String strread = new String(bu, "GBK").trim();
                    setMessage(strread, MESSAGE_RECEIVE);
                } catch (IOException e) {
                    System.out.println(e);
                }
            }
        }
    }

    /**
     * 断开连接
     */
    private void disSocket() {
        if (sock != null) {
            try {
                outx.close();
                inx.close();
                sock.close();
                sock = null;
            } catch (Exception e) {
                setMessage("error", MESSAGE_ERROR);
            }
        }
    }

    @SuppressLint("HandlerLeak")
    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.arg1) {
                case MESSAGE_ERROR:
                    disSocket();
                    strMsg.append(msg.obj + "<br>");
                    tvContent.setText(Html.fromHtml(strMsg.toString()));
                    break;
                case MESSAGE_SUCCEED:
                    strMsg.append(msg.obj + "<br>");
                    tvContent.setText(Html.fromHtml(strMsg.toString()));
                    break;
                case MESSAGE_RECEIVE:
                    //收到数据
                    strMsg.append(msg.obj);
                    if (!strMsg.toString().substring(strMsg.length() - 4, strMsg.length()).equals("<br>")) {
                        strMsg.append("<br>");
                    }
                    tvContent.setText(Html.fromHtml(strMsg.toString()));
                    svContent.fullScroll(ScrollView.FOCUS_DOWN);
                    break;
                default:
                    break;
            }
        }
    };

    /**
     * 发送消息
     */
    private void sendStrSocket(final String senddata) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String str = "<font color='#EE2C2C'>" + senddata + "</font>";
                    outx.write(str.getBytes("gbk"));//"utf-8"
                } catch (Exception e) {
                    setMessage("error on sending ", MESSAGE_ERROR);
                }
            }
        }).start();
    }


    private void setMessage(String obj, int arg1){
        Message message = new Message();
        message.arg1 = arg1;
        message.obj = obj;
        handler.sendMessage(message);
    }


    /*************************************************************server(test only)**********************************************************************/
    private String msg = "";

    public class Server {
        ServerSocket serverSocket = null;
        public final int port = 8081;

        public Server() {
            //IP地址
            try {
                InetAddress addr = InetAddress.getLocalHost();
                serverSocket = new ServerSocket(port);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void startService() {
            try {
                while (true) {
                    Socket socket = null;
                    socket = serverSocket.accept();
                    new ConnectThread(socket).start();
                    new ConnectThread1(socket).start();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        /**
         * 向客户端发送信息
         */
        class ConnectThread extends Thread {
            Socket socket = null;

            public ConnectThread(Socket socket) {
                super();
                this.socket = socket;
            }

            @Override
            public void run() {
                try {
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                    while (true) {
                        Thread.sleep(1000);
                        if (!TextUtils.isEmpty(msg)) {
                            String str = "<font color='#4F94CD'>" + msg + "</font>";
                            out.write(str.getBytes("gbk"));
                            out.flush();
                            msg = "";
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        /**
         * 接收客户端信息
         */
        class ConnectThread1 extends Thread {
            Socket socket = null;

            public ConnectThread1(Socket socket) {
                super();
                this.socket = socket;
            }

            @Override
            public void run() {
                try {
                    DataInputStream inp = new DataInputStream(socket.getInputStream());
                    while (true) {
                        byte[] bu = new byte[1024];
                        int conut = inp.read(bu);//设备重启，异常 将会一直停留在这
                        if (conut == -1) {
                            setMessage("disconnect", MESSAGE_ERROR);
                            return;
                        }
                        String strread = new String(bu, "GBK").trim();
                        setMessage(strread, MESSAGE_RECEIVE);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void sendString(String str) {
        msg = str;
    }
}