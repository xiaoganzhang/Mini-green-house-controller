package com.example.logintest14.ui.home;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;

import com.example.logintest14.R;

 public class button_ref extends AppCompatActivity {


    private Button button1;
    private TextView textView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_home);

        button1 = findViewById(R.id.button);
        textView = findViewById(R.id.textView10);
        button1.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                float number = (float)(Math.random());

                textView.setText(String.valueOf(number));
            }
        });
    }

}